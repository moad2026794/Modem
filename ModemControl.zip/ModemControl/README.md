# مدير المودم - ModemControl

تطبيق أندرويد لإدارة مودم HUAWEI 4G CPE 3: الأجهزة المتصلة، حظر وإلغاء حظر الأجهزة، الاستهلاك الكلي، جودة الإشارة، ولوحة المودم الأصلية داخل التطبيق.

## البناء
ارفع `ModemControl.zip` و `.github/workflows/build.yml` إلى مستودع GitHub ثم شغّل Build APK من تبويب Actions.
