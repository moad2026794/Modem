package com.example.modemcontrol

import android.util.Base64
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Document
import org.w3c.dom.Element

class ApiException(message: String) : Exception(message)

data class Host(
    val name: String,
    val mac: String,
    val ip: String,
    val iface: String,
    val active: Boolean,
    val extra: Map<String, String> = emptyMap()
)

private fun esc(s: String): String =
    s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;").replace("'", "&apos;")

private fun toHex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }

private fun hexToBytes(s: String): ByteArray {
    val c = s.trim()
    return ByteArray(c.length / 2) { c.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
}

private fun sha256(b: ByteArray): ByteArray = MessageDigest.getInstance("SHA-256").digest(b)

private fun sha256Hex(s: String): String = toHex(sha256(s.toByteArray(Charsets.UTF_8)))

private fun b64(b: ByteArray): String = Base64.encodeToString(b, Base64.NO_WRAP)

private fun hmac(key: ByteArray, data: ByteArray): ByteArray {
    val mac = Mac.getInstance("HmacSHA256")
    mac.init(SecretKeySpec(key, "HmacSHA256"))
    return mac.doFinal(data)
}

/** PBKDF2-HMAC-SHA256, single 32-byte block (works on all Android versions). */
private fun pbkdf2(password: ByteArray, salt: ByteArray, iterations: Int): ByteArray {
    val mac = Mac.getInstance("HmacSHA256")
    mac.init(SecretKeySpec(password, "HmacSHA256"))
    mac.update(salt)
    mac.update(byteArrayOf(0, 0, 0, 1))
    var u = mac.doFinal()
    val t = u.copyOf()
    for (i in 1 until iterations) {
        u = mac.doFinal(u)
        for (j in t.indices) {
            t[j] = (t[j].toInt() xor u[j].toInt()).toByte()
        }
    }
    return t
}

private fun randomHex(bytes: Int): String {
    val b = ByteArray(bytes)
    SecureRandom().nextBytes(b)
    return toHex(b)
}

private fun tag(xml: String, name: String): String? =
    Regex("<$name>(.*?)</$name>", RegexOption.DOT_MATCHES_ALL)
        .find(xml)?.groupValues?.get(1)?.trim()

private fun parseXml(s: String): Document =
    DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(s.byteInputStream())

private fun errMsg(code: String?): String = when (code) {
    "108001", "108002", "108006" -> "اسم المستخدم أو كلمة المرور غير صحيحة"
    "108007" -> "المودم قفل تسجيل الدخول مؤقتاً بسبب محاولات خاطئة كثيرة، انتظر بضع دقائق"
    "125002", "125003", "125001" -> "انتهت الجلسة أو رمز التحقق غير صالح، اضغط اتصال من جديد"
    "100003" -> "لا توجد صلاحية لهذه العملية"
    else -> "خطأ من المودم (الكود: $code)"
}

class HuaweiClient(private val host: String, private val log: (String) -> Unit) {
    private var cookie: String? = null
    private val tokens = ArrayDeque<String>()

    private fun updateFrom(conn: HttpURLConnection) {
        for ((k, v) in conn.headerFields) {
            if (k != null && k.equals("Set-Cookie", ignoreCase = true)) {
                for (c in v) {
                    val m = Regex("SessionID=[^;]+").find(c)
                    if (m != null) cookie = m.value
                }
            }
        }
        val one = conn.getHeaderField("__RequestVerificationTokenone")
        val two = conn.getHeaderField("__RequestVerificationTokentwo")
        val plain = conn.getHeaderField("__RequestVerificationToken")
        if (one != null) {
            tokens.clear()
            tokens.addLast(one)
            if (two != null) tokens.addLast(two)
        } else if (plain != null) {
            tokens.clear()
            plain.split("#").filter { it.isNotBlank() }.forEach { tokens.addLast(it) }
        }
    }

    private fun call(method: String, path: String, body: String? = null, logLimit: Int = 250): String {
        val conn = URL("http://$host$path").openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = 6000
        conn.readTimeout = 10000
        conn.instanceFollowRedirects = false
        cookie?.let { conn.setRequestProperty("Cookie", it) }
        conn.setRequestProperty("X-Requested-With", "XMLHttpRequest")
        if (method == "POST") {
            val t = tokens.removeFirstOrNull()
            if (t != null) conn.setRequestProperty("__RequestVerificationToken", t)
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
            conn.doOutput = true
            conn.outputStream.use { it.write((body ?: "").toByteArray(Charsets.UTF_8)) }
        }
        val code = conn.responseCode
        updateFrom(conn)
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        conn.disconnect()
        log("$method $path -> $code  ${text.take(logLimit).replace("\n", " ")}")
        if (code !in 200..299) throw ApiException("HTTP $code من المودم")
        if (text.contains("<error>")) {
            val c = Regex("<code>(\\d+)</code>").find(text)?.groupValues?.get(1)
            throw ApiException(errMsg(c))
        }
        return text
    }

    private fun ensureToken() {
        if (tokens.isEmpty()) {
            val x = call("GET", "/api/webserver/token")
            val t = tag(x, "token")
            if (t != null && tokens.isEmpty()) {
                tokens.addLast(if (t.length >= 64) t.takeLast(32) else t)
            }
        }
    }

    private fun startSession() {
        cookie = null
        tokens.clear()
        val x = call("GET", "/api/webserver/SesTokInfo")
        tag(x, "SesInfo")?.let { cookie = it }
        tag(x, "TokInfo")?.let { tokens.addLast(it) }
    }

    fun login(user: String, pass: String) {
        startSession()
        val st = call("GET", "/api/user/state-login")
        val ptype = tag(st, "password_type")
        log("نوع تسجيل الدخول: $ptype")
        var ok = false
        if (ptype != "4") {
            try {
                loginScram(user, pass)
                ok = true
            } catch (e: Exception) {
                log("فشل الدخول بطريقة SCRAM: ${e.message}")
                startSession()
            }
        }
        if (!ok) loginSha(user, pass)
        val s = call("GET", "/api/user/state-login")
        val state = tag(s, "State")
        if (state != "0") throw ApiException("لم يكتمل تسجيل الدخول (State=$state)")
    }

    private fun loginSha(user: String, pass: String) {
        val token = tokens.firstOrNull() ?: throw ApiException("لا يوجد رمز تحقق")
        val h1 = b64(sha256Hex(pass).toByteArray(Charsets.UTF_8))
        val pw = b64(sha256Hex(user + h1 + token).toByteArray(Charsets.UTF_8))
        val body = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><request>" +
                "<Username>${esc(user)}</Username><Password>$pw</Password>" +
                "<password_type>4</password_type></request>"
        call("POST", "/api/user/login", body)
    }

    private fun loginScram(user: String, pass: String) {
        val firstNonce = randomHex(32)
        val body1 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><request>" +
                "<username>${esc(user)}</username><firstnonce>$firstNonce</firstnonce>" +
                "<mode>1</mode></request>"
        val r1 = call("POST", "/api/user/challenge_login", body1)
        val salt = tag(r1, "salt") ?: throw ApiException("رد غير متوقع: لا يوجد salt")
        val iter = tag(r1, "iterations")?.toIntOrNull() ?: throw ApiException("رد غير متوقع: iterations")
        val serverNonce = tag(r1, "servernonce") ?: throw ApiException("رد غير متوقع: servernonce")

        val salted = pbkdf2(pass.toByteArray(Charsets.UTF_8), hexToBytes(salt), iter)
        val clientKey = hmac(salted, "Client Key".toByteArray(Charsets.UTF_8))
        val storedKey = sha256(clientKey)
        val authMsg = "$firstNonce,$serverNonce,$serverNonce"
        val signature = hmac(storedKey, authMsg.toByteArray(Charsets.UTF_8))
        val proof = ByteArray(clientKey.size) { (clientKey[it].toInt() xor signature[it].toInt()).toByte() }

        val body2 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><request>" +
                "<clientproof>${toHex(proof)}</clientproof><finalnonce>$serverNonce</finalnonce></request>"
        call("POST", "/api/user/authentication_login", body2)
    }

    // ------------------------------------------------------------ data

    fun hosts(): List<Host> {
        val x = try {
            call("GET", "/api/lan/HostInfo")
        } catch (e: Exception) {
            call("GET", "/api/wlan/host-list")
        }
        val doc = parseXml(x)
        val nodes = doc.getElementsByTagName("Host")
        val out = ArrayList<Host>()
        for (i in 0 until nodes.length) {
            val e = nodes.item(i) as Element
            fun f(n: String): String = e.getElementsByTagName(n).item(0)?.textContent?.trim() ?: ""
            val active = f("Active")
            val extra = LinkedHashMap<String, String>()
            val kids = e.childNodes
            for (k in 0 until kids.length) {
                val n = kids.item(k)
                if (n is Element) extra[n.tagName] = n.textContent.trim()
            }
            out.add(
                Host(
                    name = f("HostName").ifBlank { "غير معروف" },
                    mac = f("MacAddress"),
                    ip = f("IpAddress"),
                    iface = f("InterfaceType").ifBlank { f("AssociatedSsid") },
                    active = active.isBlank() || active == "1",
                    extra = extra
                )
            )
        }
        return out
    }

    /** Read-only GET used for diagnostics; logs a long part of the raw reply. */
    fun dump(path: String): String = call("GET", path, null, 3000)

    fun monthStats(): Pair<Long, Long> {
        val x = call("GET", "/api/monitoring/month-statistics")
        val dl = tag(x, "CurrentMonthDownload")?.toLongOrNull() ?: 0L
        val ul = tag(x, "CurrentMonthUpload")?.toLongOrNull() ?: 0L
        return dl to ul
    }

    fun signal(): Map<String, String> {
        val x = call("GET", "/api/device/signal")
        return mapOf(
            "rsrp" to (tag(x, "rsrp") ?: "-"),
            "sinr" to (tag(x, "sinr") ?: "-"),
            "band" to (tag(x, "band") ?: "-")
        )
    }

    // ------------------------------------------------------------ MAC filter (blocking)

    fun blockedMacs(): Set<String> {
        val x = call("GET", "/api/wlan/multi-macfilter-settings")
        val doc = parseXml(x)
        val all = doc.getElementsByTagName("*")
        val out = HashSet<String>()
        for (i in 0 until all.length) {
            val e = all.item(i) as Element
            if (e.tagName.startsWith("WifiMacFilterMac")) {
                val v = e.textContent.trim()
                if (v.isNotBlank()) out.add(v.uppercase())
            }
        }
        return out
    }

    fun setBlocked(mac: String, name: String, block: Boolean) {
        val x = call("GET", "/api/wlan/multi-macfilter-settings")
        val doc = parseXml(x)
        val ssids = doc.getElementsByTagName("Ssid")
        if (ssids.length == 0) throw ApiException("لم أجد إعدادات فلترة MAC في المودم")
        val sb = StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><request><Ssids>")
        for (i in 0 until ssids.length) {
            val s = ssids.item(i) as Element
            fun g(n: String): String = s.getElementsByTagName(n).item(0)?.textContent?.trim() ?: ""
            val status = g("WifiMacFilterStatus")
            if (status == "1") {
                throw ApiException("المودم يعمل بوضع القائمة البيضاء. غيّره من لوحة المودم إلى القائمة السوداء أولاً")
            }
            val macs = (0..9).map { g("WifiMacFilterMac$it") }.toMutableList()
            val names = (0..9).map { g("wifihostname$it") }.toMutableList()
            var newStatus = if (status.isBlank()) "0" else status
            if (block) {
                if (macs.none { it.equals(mac, ignoreCase = true) }) {
                    val slot = macs.indexOfFirst { it.isBlank() }
                    if (slot < 0) throw ApiException("قائمة الحظر ممتلئة (الحد 10 أجهزة لكل شبكة)")
                    macs[slot] = mac
                    names[slot] = name
                }
                newStatus = "2"
            } else {
                for (k in macs.indices) {
                    if (macs[k].equals(mac, ignoreCase = true)) {
                        macs[k] = ""
                        names[k] = ""
                    }
                }
            }
            sb.append("<Ssid><Index>${g("Index").ifBlank { i.toString() }}</Index>")
            sb.append("<WifiMacFilterStatus>$newStatus</WifiMacFilterStatus>")
            for (k in 0..9) {
                sb.append("<wifihostname$k>${esc(names[k])}</wifihostname$k>")
                sb.append("<WifiMacFilterMac$k>${esc(macs[k])}</WifiMacFilterMac$k>")
            }
            sb.append("</Ssid>")
        }
        sb.append("</Ssids></request>")
        ensureToken()
        call("POST", "/api/wlan/multi-macfilter-settings", sb.toString())
    }
}
