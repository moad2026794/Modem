package com.example.modemcontrol

import java.util.Locale

fun fmtBytes(b: Long): String {
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var v = b.toDouble()
    var i = 0
    while (v >= 1024 && i < units.size - 1) {
        v /= 1024
        i++
    }
    return String.format(Locale.US, if (i == 0) "%.0f %s" else "%.2f %s", v, units[i])
}
