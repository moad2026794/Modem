package com.example.modemcontrol

import android.content.Intent
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel

private val GREEN = Color(0xFF2E7D32)
private val RED = Color(0xFFC62828)

private val usageKey = Regex("(?i)(traffic|flow|byte|usage|upload|download|rx|tx)")

/** Fields in the modem's host record that look like traffic counters, as (name, bytes). */
private fun usageOf(h: Host): List<Pair<String, Long>> =
    h.extra.filter { usageKey.containsMatchIn(it.key) && it.value.toLongOrNull() != null }
        .map { it.key to it.value.toLong() }

@Composable
fun ModemApp(vm: ModemViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    val items = listOf(
        "الرئيسية" to Icons.Default.Home,
        "الأجهزة" to Icons.Default.Person,
        "اللوحة" to Icons.Default.Menu,
        "الإعدادات" to Icons.Default.Settings,
        "السجل" to Icons.Default.Info
    )
    Scaffold(
        bottomBar = {
            NavigationBar {
                items.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label, fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(vm)
                1 -> DevicesScreen(vm)
                2 -> PanelScreen(vm)
                3 -> SettingsScreen(vm)
                else -> LogScreen(vm)
            }
        }
    }
}

@Composable
fun HomeScreen(vm: ModemViewModel) {
    Column(
        Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("حالة الاتصال بالمودم", fontWeight = FontWeight.Bold)
                if (vm.connected) {
                    Text("متصل بالمودم", color = GREEN, fontWeight = FontWeight.Bold)
                } else {
                    Text("غير متصل. اذهب إلى الإعدادات واضغط حفظ واتصال.", color = RED)
                }
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("استهلاك هذا الشهر (كل الأجهزة)", fontWeight = FontWeight.Bold)
                Text("التحميل: ${fmtBytes(vm.monthDown)}")
                Text("الرفع: ${fmtBytes(vm.monthUp)}")
                Text("الإجمالي: ${fmtBytes(vm.monthDown + vm.monthUp)}", fontWeight = FontWeight.SemiBold)
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("جودة الإشارة", fontWeight = FontWeight.Bold)
                Text("RSRP: ${vm.signal["rsrp"] ?: "-"}")
                Text("SINR: ${vm.signal["sinr"] ?: "-"}")
                Text("النطاق (Band): ${vm.signal["band"] ?: "-"}")
            }
        }
        if (vm.message.isNotBlank()) Text(vm.message, color = RED)
        if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        Button(onClick = { vm.refresh() }, enabled = vm.connected && !vm.busy) { Text("تحديث") }
    }
}

@Composable
fun DevicesScreen(vm: ModemViewModel) {
    var target by remember { mutableStateOf<Host?>(null) }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("عدد الأجهزة: ${vm.devices.size}", fontWeight = FontWeight.Bold)
            OutlinedButton(onClick = { vm.refresh() }, enabled = vm.connected && !vm.busy) { Text("تحديث") }
        }
        if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (vm.message.isNotBlank()) {
            Text(vm.message, color = RED, modifier = Modifier.padding(horizontal = 16.dp))
        }
        if (vm.devices.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(if (vm.connected) "لا توجد أجهزة" else "اتصل بالمودم من الإعدادات أولاً")
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(vm.devices, key = { it.mac + it.ip }) { h ->
                    val isBlocked = h.mac.uppercase() in vm.blocked
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(h.name, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                                if (isBlocked) Text("محظور", color = RED, fontWeight = FontWeight.Bold)
                                else Text(if (h.active) "متصل" else "غير متصل", color = if (h.active) GREEN else Color.Gray)
                            }
                            Text("IP: ${h.ip}", fontSize = 13.sp)
                            Text("MAC: ${h.mac}", fontSize = 13.sp)
                            if (h.iface.isNotBlank()) Text("الشبكة: ${h.iface}", fontSize = 13.sp)
                            val usage = usageOf(h)
                            if (usage.isEmpty()) {
                                Text("استهلاك الجهاز: غير متوفر من المودم", fontSize = 13.sp, color = Color.Gray)
                            } else {
                                usage.forEach { (k, v) ->
                                    Text(
                                        "$k: ${String.format(java.util.Locale.US, "%,d", v / 1024)} KB",
                                        fontSize = 13.sp, fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                            TextButton(
                                onClick = { if (isBlocked) vm.toggleBlock(h) else target = h },
                                enabled = vm.connected && !vm.busy && h.mac.isNotBlank()
                            ) { Text(if (isBlocked) "إلغاء الحظر" else "حظر الجهاز", color = if (isBlocked) GREEN else RED) }
                        }
                    }
                }
            }
        }
    }
    target?.let { h ->
        AlertDialog(
            onDismissRequest = { target = null },
            title = { Text("حظر ${h.name}؟") },
            text = {
                Text(
                    "سيُمنع هذا الجهاز من الاتصال بشبكة الواي فاي. " +
                            "تنبيه: إذا كان هذا هو جوالك نفسه فستفقد الاتصال، ولن يمكنك إلغاء الحظر " +
                            "إلا من جهاز آخر أو من لوحة المودم."
                )
            },
            confirmButton = {
                TextButton(onClick = { vm.toggleBlock(h); target = null }) { Text("حظر", color = RED) }
            },
            dismissButton = { TextButton(onClick = { target = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun PanelScreen(vm: ModemViewModel) {
    val url = "http://${vm.host.trim()}"
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                webViewClient = WebViewClient()
                loadUrl(url)
            }
        }
    )
}

@Composable
fun SettingsScreen(vm: ModemViewModel) {
    Column(
        Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("بيانات المودم", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        OutlinedTextField(
            value = vm.host, onValueChange = { vm.host = it },
            label = { Text("عنوان المودم") }, singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = vm.user, onValueChange = { vm.user = it },
            label = { Text("اسم المستخدم") }, singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = vm.pass, onValueChange = { vm.pass = it },
            label = { Text("كلمة مرور لوحة المودم") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )
        if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        Button(onClick = { vm.connect() }, enabled = !vm.busy) { Text("حفظ واتصال") }
        if (vm.message.isNotBlank()) Text(vm.message, color = RED)
        if (vm.connected) Text("متصل بالمودم", color = GREEN, fontWeight = FontWeight.Bold)
        Text(
            "تنبيهات: يجب أن يكون الجوال متصلاً بواي فاي المودم. كلمة المرور هي نفسها التي تدخل بها " +
                    "صفحة 192.168.8.1. كرّر المحاولة بحذر، لأن المودم يقفل الدخول مؤقتاً بعد عدة محاولات خاطئة. " +
                    "تُحفظ كلمة المرور على جوالك فقط.",
            fontSize = 13.sp
        )
    }
}

@Composable
fun LogScreen(vm: ModemViewModel) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("سجل الاتصال", fontWeight = FontWeight.Bold)
            OutlinedButton(onClick = { vm.diagnose() }, enabled = vm.connected && !vm.busy) { Text("تشخيص") }
            OutlinedButton(onClick = {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, vm.logs.reversed().joinToString("\n"))
                }
                context.startActivity(Intent.createChooser(intent, "مشاركة السجل"))
            }) { Text("مشاركة") }
        }
        LazyColumn(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(vm.logs) { line ->
                Text(line, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}
