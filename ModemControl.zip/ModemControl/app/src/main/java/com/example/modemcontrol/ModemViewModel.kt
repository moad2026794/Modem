package com.example.modemcontrol

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ModemViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("modem", Context.MODE_PRIVATE)

    var host by mutableStateOf(prefs.getString("host", "192.168.8.1") ?: "192.168.8.1")
    var user by mutableStateOf(prefs.getString("user", "admin") ?: "admin")
    var pass by mutableStateOf(prefs.getString("pass", "") ?: "")

    var busy by mutableStateOf(false)
    var connected by mutableStateOf(false)
    var message by mutableStateOf("")

    var devices by mutableStateOf<List<Host>>(emptyList())
    var blocked by mutableStateOf<Set<String>>(emptySet())
    var monthDown by mutableLongStateOf(0L)
    var monthUp by mutableLongStateOf(0L)
    var signal by mutableStateOf<Map<String, String>>(emptyMap())

    val logs = mutableStateListOf<String>()

    private var client: HuaweiClient? = null

    fun addLog(s: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        logs.add(0, "$t  $s")
        while (logs.size > 200) logs.removeAt(logs.size - 1)
    }

    fun save() {
        prefs.edit()
            .putString("host", host.trim())
            .putString("user", user.trim())
            .putString("pass", pass)
            .apply()
    }

    private fun launchOp(block: () -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            busy = true
            message = ""
            try {
                block()
            } catch (e: Exception) {
                message = e.message ?: e.toString()
                addLog("خطأ: $message")
            } finally {
                busy = false
            }
        }
    }

    fun connect() {
        save()
        connected = false
        launchOp {
            addLog("الاتصال بـ ${host.trim()}")
            val c = HuaweiClient(host.trim()) { addLog(it) }
            c.login(user.trim(), pass)
            client = c
            connected = true
            addLog("تم تسجيل الدخول")
            loadAll(c)
        }
    }

    fun refresh() {
        val c = client
        if (c == null) {
            message = "اضغط اتصال من الإعدادات أولاً"
            return
        }
        launchOp { loadAll(c) }
    }

    private fun loadAll(c: HuaweiClient) {
        try {
            devices = c.hosts()
        } catch (e: Exception) {
            addLog("الأجهزة: ${e.message}")
            message = "تعذر قراءة الأجهزة: ${e.message}"
        }
        try {
            blocked = c.blockedMacs()
        } catch (e: Exception) {
            addLog("قائمة الحظر: ${e.message}")
        }
        try {
            val s = c.monthStats()
            monthDown = s.first
            monthUp = s.second
        } catch (e: Exception) {
            addLog("الاستهلاك: ${e.message}")
        }
        try {
            signal = c.signal()
        } catch (e: Exception) {
            addLog("الإشارة: ${e.message}")
        }
    }

    fun diagnose() {
        val c = client
        if (c == null) {
            message = "اضغط اتصال من الإعدادات أولاً"
            return
        }
        launchOp {
            addLog("===== بدء التشخيص =====")
            val paths = listOf(
                "/api/lan/HostInfo",
                "/api/wlan/host-list",
                "/api/monitoring/traffic-statistics",
                "/api/monitoring/month-statistics",
                "/api/device/information"
            )
            for (p in paths) {
                try {
                    c.dump(p)
                } catch (e: Exception) {
                    addLog("$p: ${e.message}")
                }
            }
            addLog("===== انتهى التشخيص =====")
            message = "تم تسجيل نتيجة التشخيص في تبويب السجل"
        }
    }

    fun toggleBlock(h: Host) {
        val c = client
        if (c == null) {
            message = "اضغط اتصال من الإعدادات أولاً"
            return
        }
        launchOp {
            val isBlocked = h.mac.uppercase() in blocked
            c.setBlocked(h.mac, h.name, !isBlocked)
            blocked = c.blockedMacs()
            message = if (isBlocked) "تم إلغاء حظر ${h.name}" else "تم حظر ${h.name}"
        }
    }
}
